# ADY201m - Phân tích và dự đoán khách hàng rời bỏ dịch vụ thẻ tín dụng

Đồ án cuối kỳ môn **AI, DS with Python & SQL (ADY201m)** - FPT University, lớp **AI2107**, **Nhóm 04**.
Giảng viên hướng dẫn: **Ngô Trường Minh**.

Dự án dùng bộ dữ liệu **BankChurners** (Kaggle, 10.127 khách hàng thẻ tín dụng) để tìm ra các dấu hiệu khiến khách hàng hủy thẻ, sau đó xây dựng **thang điểm rủi ro (SQL)** và **mô hình Random Forest (Python)** để nhận diện sớm khách có nguy cơ rời bỏ, giúp bộ phận chăm sóc khách hàng (CSKH) giữ chân đúng đối tượng.

## Thành viên

| Họ và tên | MSSV | Vai trò |
| --- | --- | --- |
| Nguyễn Văn Kiên | HE200682 | Trưởng nhóm |
| Tống Việt Thảo | HE204303 | Thành viên |
| Nguyễn Anh Tới | HE201009 | Thành viên |

## Kết quả nổi bật

| Chỉ số | Giá trị |
|---|---|
| Quy mô dữ liệu | 10.127 khách hàng (8.500 ở lại, 1.627 rời bỏ) |
| Tỷ lệ rời bỏ chung | **16,07%** (mất cân bằng 5,22 : 1) |
| Ngưỡng rủi ro số lần quẹt thẻ | **≤ 60 lần/năm** chứa 85,50% tổng khách rời bỏ |
| Risk Score (SQL) | Điểm 6: 100% rời bỏ; điểm 5: 91,53%; điểm 0-1: dưới 2% |
| Random Forest - Recall | **91,38%** (bắt đúng 297/325 khách rời bỏ) |
| Random Forest - F1-Score | 82,27% |
| Random Forest - Accuracy / Precision | 93,68% / 74,81% |

## Sơ đồ thư mục

```text
ADY201m-Nhom04-AI2107-Credit-Card-Churn/
│
├── data/
│   ├── raw/
│   │   └── BankChurners.csv               # Dữ liệu gốc (10.127 dòng x 23 cột)
│   └── cleaned/
│       └── BankChurners_clean.csv         # Dữ liệu sạch (10.127 dòng x 21 cột)
│
├── notebooks/
│   ├── 01_Data_Cleaning.ipynb             # Giai đoạn 1: kiểm định và làm sạch dữ liệu
│   ├── 02_EDA.ipynb                       # Giai đoạn 2: phân tích dữ liệu khám phá
│   └── 03_Machine_Learning.ipynb          # Giai đoạn 3: Random Forest + watchlist
│
├── sql/
│   ├── 01_Create_Tables.sql               # Tạo 2 bảng Customers, Card_Activity
│   └── 02_SQL_Analysis.sql                # Query 1-4: ngưỡng rủi ro, Risk Score
│
├── report/
│   └── Final_Project_Nhom04_AI2107.docx   # Báo cáo đồ án cuối kỳ
│
├── images/                                # Biểu đồ dùng trong README
│
└── README.md
```

## Giải thích cấu trúc dự án

| Thành phần | Nội dung thực hiện | Kết quả |
|---|---|---|
| **01. Data Cleaning** | Kiểm tra trùng, thiếu, nhãn `Unknown`, logic miền giá trị và ngoại lai (IQR). Loại 2 cột Naive Bayes để tránh rò rỉ dữ liệu, mã hóa `Attrition_Flag` thành 0/1. | `BankChurners_clean.csv` + bảng đối chiếu Before/After |
| **SQL** | Thiết kế CSDL 2 bảng (`Customers`, `Card_Activity`), truy vấn JOIN, GROUP BY, CASE WHEN, CTE, Window Function để tìm ngưỡng rủi ro và chấm điểm Risk Score 0-6. | Bảng thống kê + watchlist Top 20 |
| **02. EDA** | Phân bố nhãn, tỷ lệ rời bỏ theo thuộc tính, ma trận tương quan, phân phối hành vi dùng thẻ. | Biểu đồ + insight + danh sách 9 biến cho ML |
| **03. Machine Learning** | Random Forest (200 cây, `max_depth=8`, `class_weight="balanced"`), đánh giá bằng Recall và F1-Score, Feature Importance, watchlist. | Mô hình + 100 khách cần CSKH liên hệ |
| **Dashboard** | Dashboard "Credit Card Churn" trên Looker Studio với bộ lọc và scorecard. | Trực quan hóa tương tác cho quản lý |

## Workflow

**Business Understanding → Data Cleaning → SQL Analysis → EDA → Machine Learning → Dashboard**

## 1. Bài toán

- **Vấn đề:** Ngân hàng mất khách hàng thẻ tín dụng mà không kịp nhận biết trước (1.627/10.127 khách, tương ứng 16,07%).
- **Mục tiêu:** Nhận diện sớm khách có nguy cơ rời bỏ để CSKH can thiệp đúng đối tượng thay vì chăm sóc dàn trải.
- **Hướng tiếp cận:** Phân tích mô tả (so sánh hai nhóm) → phân tích chẩn đoán (ngưỡng, tương quan, Risk Score) → phân tích dự đoán (Random Forest).
- **Vì sao dùng Recall và F1-Score:** Nếu đoán tất cả khách đều "ở lại" thì Accuracy vẫn đạt 83,93% nhưng bỏ sót 100% khách hủy thẻ.

## 2. Dữ liệu và cơ sở dữ liệu

- **Nguồn:** [Credit Card Customers - Kaggle](https://www.kaggle.com/datasets/sakshigoyal7/credit-card-customers) (`BankChurners.csv`).
- **Quy mô:** 10.127 dòng x 23 cột (gốc) → 21 cột (sạch).
- **Tổ chức CSDL (SQL Server, CSDL `bank_churn`):** dữ liệu sạch nạp vào bảng tạm `BankChurners_Staging`, sau đó tách thành 2 bảng liên kết qua khóa ngoại `CLIENTNUM`.

![Database schema](images/db_schema.png)

| Bảng | Số cột | Nội dung |
|---|---|---|
| `Customers` | 11 | Hồ sơ khách hàng và mức gắn kết (`Total_Relationship_Count`) |
| `Card_Activity` | 12 | Hoạt động thẻ: giao dịch, dư nợ, hạn mức, số lần liên hệ |

## 3. Tiền xử lý dữ liệu (`01_Data_Cleaning.ipynb`)

| Vấn đề | Quyết định |
|---|---|
| Dòng trùng, ô NaN, `CLIENTNUM` trùng | Không có |
| Nhãn `Unknown` (30,08% khách có ít nhất 1 ô) ở `Education_Level`, `Marital_Status`, `Income_Category` | Giữ làm nhóm riêng, không xóa dòng để tránh lệch mẫu |
| Ngoại lai (IQR) ở `Credit_Limit`, `Total_Trans_Amt` (8,85% - 9,72%) | Giữ nguyên 100% vì là khách VIP thật, không phải lỗi nhập liệu |
| 2 cột `Naive_Bayes_Classifier_...` | Loại bỏ để tránh rò rỉ dữ liệu |
| `Attrition_Flag` dạng chuỗi | Mã hóa `Existing Customer` = 0, `Attrited Customer` = 1 |

Kiểm tra logic: `Credit_Limit = Total_Revolving_Bal + Avg_Open_To_Buy` (sai số 0), không ai dư nợ vượt hạn mức, tuổi nhỏ nhất lúc mở thẻ là 23.

## 4. Phân tích bằng SQL (`sql/02_SQL_Analysis.sql`)

| Query | Nội dung | Phát hiện chính |
|---|---|---|
| **Query 1** | So sánh hành vi trung bình hai nhóm | Khách rời bỏ quẹt ~45 lần và ~3.095 USD/năm, so với ~69 lần và ~4.655 USD ở nhóm ở lại |
| **Query 2** | Ngưỡng rủi ro theo `Total_Trans_Ct` | Mốc **60 lần/năm** là ranh giới: vùng ≤ 60 lần chứa 85,50% khách rời bỏ. Nhóm 41-50 lần cao nhất (48,40%) |
| **Query 3** | 5 dấu hiệu phụ trợ | Q4/Q1 < 0,5: 50,88% rời bỏ; nợ 1-499 USD: 84,00%; gọi tổng đài 6 lần: 54/54 hủy thẻ; dùng 1-2 sản phẩm: 25,6% - 27,8% |
| **Query 4** | Risk Score 0-6 và watchlist Top 20 | Điểm càng cao tỷ lệ rời bỏ càng tăng rõ |

**Risk Score** cộng 6 dấu hiệu (mỗi dấu hiệu 1 điểm): `Total_Trans_Ct <= 60`, `Total_Ct_Chng_Q4_Q1 < 0.5`, `Total_Revolving_Bal < 500`, `Months_Inactive_12_mon >= 3`, `Contacts_Count_12_mon >= 3`, `Total_Relationship_Count <= 2`.

![Risk Score](images/sql_risk_score_table.png)

**Đề xuất nhóm chăm sóc:** ≥ 4 điểm → CSKH gọi điện trực tiếp; 3 điểm → gửi ưu đãi tự động; ≤ 2 điểm → duy trì chăm sóc thường.

## 5. Phân tích khám phá EDA (`02_EDA.ipynb`)

### 5.1 Phân bố biến mục tiêu

![Phân bố Attrition](images/01_phan_bo_attrition.png)

8.500 khách ở lại (83,93%) so với 1.627 khách rời bỏ (16,07%). Cứ khoảng 6 khách thì có 1 khách rời bỏ.

### 5.2 Nhân khẩu học không phải nguyên nhân hủy thẻ

Tỷ lệ rời bỏ theo giới tính, học vấn, hôn nhân, thu nhập, hạng thẻ đều bám sát mức trung bình 16,07%; tuổi, số tháng gắn bó, số người phụ thuộc có |r| < 0,02. Vì vậy nhóm loại cả 8 biến này khỏi mô hình.

| | |
|---|---|
| ![Gender](images/02a_churn_gender.png) | ![Income](images/02d_churn_income.png) |

### 5.3 Ma trận tương quan

![Correlation heatmap](images/03_correlation_heatmap.png)

| Biến | r với `Attrition_Flag` |
|---|---|
| `Total_Trans_Ct` | −0,37 |
| `Total_Ct_Chng_Q4_Q1` | −0,29 |
| `Total_Revolving_Bal` | −0,26 |
| `Contacts_Count_12_mon` | +0,20 |
| `Avg_Utilization_Ratio` | −0,18 |
| `Months_Inactive_12_mon` | +0,15 |
| `Credit_Limit`, tuổi, số tháng gắn bó | gần 0 |

### 5.4 Hành vi dùng thẻ

| | |
|---|---|
| ![Total_Trans_Ct](images/05_kde_total_trans_ct.png) | ![Scatter](images/06_scatter_trans_ct_amt.png) |
| Nhóm rời bỏ tập trung ở 40-45 lần/năm; hai phân phối giao nhau sát mốc 60 lần | Khách rời bỏ dồn ở góc ≤ 60 lần và ≤ 5.000 USD |
| ![Q4/Q1](images/07_kde_ct_chng_q4_q1.png) | ![Revolving](images/08_kde_revolving_bal.png) |
| Nhóm rời bỏ giảm mạnh đà quẹt thẻ cuối năm (đỉnh ~0,53) | Nhóm rời bỏ vọt lên tại 0 USD |

| | | |
|---|---|---|
| ![Contacts](images/09a_churn_contacts.png) | ![Inactive](images/09b_churn_months_inactive.png) | ![Relationship](images/09c_churn_relationship.png) |
| Gọi tổng đài càng nhiều càng dễ hủy thẻ | Rủi ro cao nhất ở mốc 3-4 tháng không giao dịch | Dùng 1-2 sản phẩm dễ rời bỏ hơn |

### 5.5 Insight không hiển nhiên

1. **Trung bình che mất khác biệt:** trung vị dư nợ xoay vòng của nhóm rời bỏ bằng 0 USD so với 1.364 USD ở nhóm ở lại.
2. **Rủi ro không đơn điệu:** nhóm quẹt 41-50 lần rời bỏ nhiều hơn nhóm ≤ 30 lần (48,40% so với 29,23%). Rủi ro đến từ nhóm *đang giảm dùng thẻ*, không phải nhóm ít dùng từ trước.
3. **Hạn mức tín dụng không dự báo được rời bỏ** (r = −0,02), trong khi hành vi dùng thẻ có tương quan rõ.

## 6. Mô hình Machine Learning (`03_Machine_Learning.ipynb`)

- **Thuật toán:** Random Forest Classifier (scikit-learn).
- **Chia dữ liệu:** Train/Test = 80/20, `stratify=y`, `random_state=42` (8.101 / 2.026 khách).
- **Siêu tham số:** `n_estimators=200`, `max_depth=8`, `class_weight="balanced"`.
- **9 biến đầu vào:** `Total_Relationship_Count`, `Months_Inactive_12_mon`, `Contacts_Count_12_mon`, `Total_Revolving_Bal`, `Total_Amt_Chng_Q4_Q1`, `Total_Trans_Amt`, `Total_Trans_Ct`, `Total_Ct_Chng_Q4_Q1`, `Avg_Utilization_Ratio`.

| Accuracy | Precision | Recall | F1-Score |
|---|---|---|---|
| 93,68% | 74,81% | **91,38%** | 82,27% |

| Ma trận nhầm lẫn | Feature Importance |
|---|---|
| ![Confusion matrix](images/10_confusion_matrix.png) | ![Feature importance](images/11_feature_importance.png) |

- Bắt đúng **297/325** khách rời bỏ, bỏ sót 28 người, cảnh báo nhầm 100 người.
- `Total_Trans_Ct` và `Total_Trans_Amt` đóng góp lớn nhất, tiếp theo là `Total_Revolving_Bal` và `Total_Ct_Chng_Q4_Q1`, khớp với kết quả EDA.
- **Watchlist:** 100 khách hiện hữu bị mô hình dự đoán rời bỏ, sắp xếp theo số lần quẹt thẻ thấp nhất để CSKH gọi trước.

## 7. Dashboard Looker Studio

Dashboard "Credit Card Churn" dùng `BankChurners_clean.csv`, gồm 2 bộ lọc (`Months_Inactive_12_mon`, `Total_Relationship_Count`), 4 scorecard (10.127 khách; trung bình `Total_Trans_Ct` = 64,86; `Total_Revolving_Bal` = 1.162,81; tỷ lệ rời bỏ 16,07%), biểu đồ cột và biểu đồ vành khuyên.

![Dashboard](images/dashboard_looker_studio.png)

## 8. Đề xuất hành động

1. Theo dõi hằng tháng đà giao dịch Q4/Q1 và số tháng không giao dịch để can thiệp trước khi khách hủy thẻ.
2. Khách có Risk Score ≥ 4 hoặc nằm trong watchlist: CSKH gọi điện, ưu tiên khách chi tiêu lớn.
3. Khách dùng 1-2 sản phẩm: đề xuất dùng thêm sản phẩm (từ 3 sản phẩm trở lên tỷ lệ rời bỏ giảm còn 10,5% - 17,3%).
4. Khách gọi tổng đài từ 3 lần trở lên: ưu tiên xử lý khiếu nại.

## Cách chạy lại dự án

```bash
pip install pandas numpy seaborn matplotlib scikit-learn jupyter
cd notebooks
jupyter notebook
```

Chạy lần lượt `01_Data_Cleaning.ipynb` → `02_EDA.ipynb` → `03_Machine_Learning.ipynb` (đường dẫn dữ liệu là `../data/...`, tính từ thư mục `notebooks/`).

Với SQL Server: tạo CSDL `bank_churn`, nhập `data/cleaned/BankChurners_clean.csv` thành bảng `dbo.BankChurners_Staging`, rồi chạy `sql/01_Create_Tables.sql` và `sql/02_SQL_Analysis.sql`.

## Nguyên tắc chung

1. Không chỉnh sửa trực tiếp dữ liệu gốc: mọi bước làm sạch chạy trên bản sao `df_clean`.
2. Mọi quyết định giữ hoặc loại dữ liệu đều có bằng chứng và lý do.
3. Loại bỏ biến gây rò rỉ dữ liệu (Naive Bayes) trước khi phân tích.
4. Đánh giá mô hình bằng Recall và F1-Score vì dữ liệu mất cân bằng.
